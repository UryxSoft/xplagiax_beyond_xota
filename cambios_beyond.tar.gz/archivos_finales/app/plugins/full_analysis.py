"""
app/plugins/full_analysis.py — Complete XplagiaX forensic pipeline.

Wraps PluginOrchestrator.run() to execute all enabled analyses:
    Desklib AI detection → Stylometric → Hallucination → Reasoning →
    Perplexity → Hybrid Segment → Watermark →
    Forensic Report Generation

Returns the full forensic report as JSON + optionally HTML.
"""

import glob
import logging
import os
import tempfile
import time
from typing import Any, Dict

# P-06: dedicated subdirectory reduces glob() scope from all of /tmp to
# only our reports — O(F_total) → O(F_forensic), grows more slowly.
_REPORT_DIR = os.path.join(tempfile.gettempdir(), "xplagiax_reports")
os.makedirs(_REPORT_DIR, mode=0o700, exist_ok=True)


def _cleanup_old_reports(directory: str, prefix: str, max_age_seconds: int) -> None:
    """Delete report files older than max_age_seconds to prevent disk exhaustion."""
    cutoff = time.time() - max_age_seconds
    for path in glob.glob(os.path.join(directory, f"{prefix}*.html")):
        try:
            if os.path.getmtime(path) < cutoff:
                os.remove(path)
        except OSError:
            pass

from app.plugins.base import BasePlugin

logger = logging.getLogger(__name__)

# ── CitationDetector singleton (CoW-safe, no network) ────────────
# P-09: reuse shared singleton via factory — avoids double spaCy model load.
_citation_detector = None
try:
    from app.antiplagio.citation.detector import ZoneType, get_citation_detector
    _citation_detector = get_citation_detector()
    logger.info("CitationDetector singleton loaded (full_analysis)")
except Exception as _exc:
    logger.warning("CitationDetector unavailable for full_analysis: %s", _exc)

# ── Module-level engine loading (shared via CoW) ──────────────────
_available = False

try:
    from app.engine.plugin_orchestrator import (
        PluginConfig, initialize_orchestrator, get_orchestrator,
    )
    initialize_orchestrator(PluginConfig(
        enable_stylometric=True,
        enable_hallucination=True,
        enable_reasoning=True,
        enable_perplexity=True,
        enable_hybrid_segment=True,
        enable_watermark=os.getenv("ENABLE_WATERMARK", "0") == "1",
        enable_forensic_report=True,
        forensic_output_format="html",
        perplexity_dict_path=os.getenv("PERPLEXITY_DICT_PATH"),
        perplexity_tier2=os.getenv("PERPLEXITY_TIER2", "1") == "1",
    ))
    _available = True
    _orch = get_orchestrator()
    logger.info("XplagiaX PluginOrchestrator loaded — plugins: %s",
                ", ".join(_orch.active_plugins()) if _orch else "none")
except Exception as exc:
    logger.warning("XplagiaX engine not available: %s", exc)


class FullAnalysisPlugin(BasePlugin):

    def name(self) -> str:
        return "full_analysis"

    def health(self) -> bool:
        return _available and get_orchestrator() is not None

    def description(self) -> str:
        return (
            "Complete XplagiaX forensic pipeline: Desklib AI detection, "
            "stylometric, hallucination, reasoning, perplexity, segment heatmap, "
            "watermark, and forensic report generation."
        )

    def analyze(self, text: str) -> Dict[str, Any]:
        orch = get_orchestrator()
        if not _available or orch is None:
            return {
                "error": "XplagiaX engine not loaded. Ensure the Desklib AI "
                         "detector model is reachable and all dependencies installed.",
                "required_files": [
                    "detector_final.py (Desklib AI-text-detector model)",
                    "stylometric_profiler.py",
                    "hallucination_profile.py",
                    "reasoning_profiler.py",
                    "perplexity_profiler.py",
                    "hybrid_segment_detector.py",
                    "forensic_reports.py",
                ],
            }

        result = orch.run(text)
        det = result.get("detection_result")
        aa = result.get("additional_analyses", {})
        fr = result.get("forensic_report")

        response: Dict[str, Any] = {
            "detection": {
                "prediction": det.prediction if det else "Unknown",
                "confidence": det.confidence if det else 0.0,
                "human_percentage": det.human_percentage if det else 50.0,
                "ai_percentage": det.ai_percentage if det else 50.0,
                "detected_model": det.detected_model if det else None,
                "uncertainty_zone": det.uncertainty_zone if det else True,
            },
        }

        if fr is not None:
            response["forensic"] = {
                "report_id": fr.report_id,
                "verdict": fr.verdict,
                "confidence": fr.confidence,
                "word_count": fr.word_count,
                "scores": {
                    "neural": fr.neural_score,
                    "statistical": fr.statistical_score,
                    "stylometric": fr.stylometric_score,
                    "reasoning": fr.reasoning_score,
                    "watermark": fr.watermark_score,
                },
                "executive_summary": fr.executive_summary,
                "evidence_count": len(fr.evidence_points),
            }
            try:
                _cleanup_old_reports(_REPORT_DIR, prefix="forensic_", max_age_seconds=3600)
                tmp = tempfile.NamedTemporaryFile(
                    suffix=".html", prefix="forensic_",
                    dir=_REPORT_DIR, delete=False,
                )
                tmp_name = tmp.name
                tmp.close()
                try:
                    orch.export_html(fr, tmp_name)
                    response["forensic"]["html_report_path"] = tmp_name
                except Exception:
                    try:
                        os.unlink(tmp_name)
                    except OSError:
                        pass
                    raise
            except Exception as exc:
                logger.warning("HTML report generation failed: %s", exc)

        if "perplexity" in aa:
            response["perplexity"] = {
                "ai_score": aa["perplexity"].get("ai_score", 0),
                "risk_level": aa["perplexity"].get("risk_level", "N/A"),
                "tier": aa["perplexity"].get("tier", "tier1"),
            }

        if "hybrid_segment" in aa:
            hs = aa["hybrid_segment"]
            response["segment_analysis"] = {
                "classification": hs.get("classification", "N/A"),
                "risk_level": hs.get("risk_level", "N/A"),
                "global_ai_score": hs.get("global_ai_score", 0),
                "total_paragraphs": hs.get("total_paragraphs", 0),
                "breakpoint_count": hs.get("breakpoint_count", 0),
                "paragraph_scores": hs.get("paragraph_scores", []),
            }

        # Tier-1 model-agnostic signals + the late-fusion verdict (surface verbatim).
        # verdict_uncertainty carries the abstention reason when verdict == "Inconclusive"
        # (short text / gray band / seed disagreement / code / quotes / contradictory
        # evidence) — clients must be able to see WHY the system abstained.
        for _key in ("author_signature", "discourse_structure", "semantic_consistency",
                     "fusion", "verdict_uncertainty"):
            if _key in aa:
                response[_key] = aa[_key]

        if _citation_detector is not None:
            try:
                cit = _citation_detector.analyze(text)
                response["zone_analysis"] = {
                    "dominant_style": cit.dominant_style.value,
                    "style_consistency": round(cit.style_consistency * 100, 1),
                    "citation_coverage": round(cit.citation_coverage * 100, 1),
                    "total_inline_citations": len(cit.inline_citations),
                    "total_bibliography": len(cit.bibliography),
                    "orphan_citations": len(cit.orphan_citations),
                    "uncited_bibliography": len(cit.uncited_bibliography),
                    "zones": [
                        {
                            "type": z.zone_type.value,
                            "has_citation": z.has_valid_citation,
                            "plagiarism_risk": round(z.plagiarism_risk, 2),
                            "text_preview": z.text[:120],
                        }
                        for z in cit.zones
                        if z.zone_type != ZoneType.BIBLIOGRAPHY
                    ],
                }
            except Exception as exc:
                logger.warning("Zone analysis failed in full_analysis: %s", exc)

        response["summary"] = orch.summary(result)
        return response
