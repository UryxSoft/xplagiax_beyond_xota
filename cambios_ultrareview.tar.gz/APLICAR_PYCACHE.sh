#!/bin/sh
# Untrack the 23 already-gitignored .pyc files (safe: files stay on disk,
# git just stops tracking them). Run this from the repo root AFTER applying
# fix_ultrareview.patch.
git rm --cached -r --quiet \
  app/__pycache__ \
  app/engine/__pycache__ \
  app/plugins/__pycache__
echo "Done — pycache untracked. Review with: git status --short"
